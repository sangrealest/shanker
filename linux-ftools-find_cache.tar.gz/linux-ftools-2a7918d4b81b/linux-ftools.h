// TODO: READ the @VERSION from configure.ac 
#define LINUX_FTOOLS_VERSION "1.3.0"
